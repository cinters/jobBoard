// Define variables to store the HTML elements we will manipulate
const jobList = document.getElementById("job-list");
const jobFilter = document.getElementById("job-filter");

// Fetch the jobs data from the jobs.json file
fetch("jobs.json")
  .then(response => response.json())
  .then(data => {
    // Store the jobs array in a variable
    const jobs = data.jobs;

    // Define a function to display the jobs in the HTML file
    function displayJobs(jobs) {
      // Clear the jobList element
      jobList.innerHTML = "";

      // Loop through the jobs array and create an HTML element for each job
      jobs.forEach(job => {
        // Create a new HTML element for the job
        const jobElement = document.createElement("div");
        jobElement.classList.add("job");

        // Populate the HTML element with job data
        jobElement.innerHTML = `
          <h2>${job.title}</h2>
          <p><strong>Company:</strong> ${job.company}</p>
          <p><strong>Location:</strong> ${job.location}</p>
          <p><strong>Description:</strong> ${job.description}</p>
          <p><strong>Salary:</strong> ${job.salary}</p>
          <a href="${job.applyLink}" target="_blank">Apply Now</a>
        `;

        // Add the job element to the jobList element
        jobList.appendChild(jobElement);
      });
    }

    // Call the displayJobs function to initially display all jobs
    displayJobs(jobs);

    // Define a function to filter the jobs by keyword and/or location
    function filterJobs() {
      // Get the value of the filter input element
      const filterValue = jobFilter.value.toLowerCase();

      // Filter the jobs array based on the filter value
      const filteredJobs = jobs.filter(job => {
        return (
          job.title.toLowerCase().includes(filterValue) ||
          job.company.toLowerCase().includes(filterValue) ||
          job.location.toLowerCase().includes(filterValue)
        );
      });

      // Call the displayJobs function to display the filtered jobs
      displayJobs(filteredJobs);
    }

    // Add an event listener to the filter input element to call the filterJobs function when the value changes
    jobFilter.addEventListener("input", filterJobs);
  });
